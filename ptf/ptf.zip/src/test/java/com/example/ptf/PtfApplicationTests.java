package com.example.ptf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PtfApplicationTests {

	@Test
	void contextLoads() {
	}

}
